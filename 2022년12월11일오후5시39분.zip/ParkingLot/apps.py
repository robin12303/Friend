from django.apps import AppConfig


class ParkinglotPageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ParkingLot'
