from django.apps import AppConfig


class BillpaymentPageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BillPayment'
